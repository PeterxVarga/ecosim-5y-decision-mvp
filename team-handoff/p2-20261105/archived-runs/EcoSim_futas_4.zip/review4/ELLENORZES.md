# Negyedik ellenőrzés – javuló pontszám és tartalék

2026. november 3. · X-Challenge 2026 Selejtező · I piac · Jutalom a nap végén · P1/5.

**Mentett és újratöltve igazolt: 58,72 SmartCity index; 352 904 ECU tartalék; 0 hitel.** Az előző 56,73 / 248 098 ECU tervhez képest **+1,99 pont és +104 806 ECU tartalék**. Ez a vizsgált P1-előnézetek közül a kiválasztott változat; a teljes ötéves városi optimumot nem igazolja.

## Az öt új döntés

| Mező | Előző mentés | Végleges |
|---|---:|---:|
| institutions.bureau.wage | 534 | 990 |
| income.services.parkingManagementCost | 6 | 10 |
| income.services.communalCost | 7.3 | 5 |
| income.services.servicesCost | 33.2 | 50 |
| income.taxes.business | 0.8 | 0.3 |

A víz–csatorna–távhő díja 33,2-ről 50-re nő (+50,6%), a parkolási díj 6-ról 10-re (+66,7%). Ezek magasabb díjterhek az érintett felhasználóknak. A kommunális szolgáltatási díj 7,3-ról 5-re csökken; a temetkezési díj 20, a lakbér 30, a közlekedési díj 10,5 marad. A vállalkozási adó 0,8%-ról 0,3%-ra csökken. A városházi bér 534-ről 990-re nő. A felület a 0%-os vállalkozásiadó-kérést 0,3%-ra, az 1200-as városházi bérkérést 990-re, a nullás kommunális díjkérést 5-re korlátozta; a végleges terv kizárólag az elfogadott értékeket tartalmazza.

A 12, 13, 27, 32 projekt, az intézményszámok és a közlekedési beállítások változatlanok. A nagyobb vízdíj önmagában rontott egyes lakossági/szociális előnézeti tényezőkön. A kiválasztást a súlyozott összindex és a költségvetés együttes javulása támasztja alá; nem állítom, hogy minden részmutató javult.

## Nyolc felületi összehasonlítás

A címkék próbakéréseket is tartalmaznak; a ténylegesen elfogadott mezőértékek külön szerepelnek a checks.json naplóban.

| Változat | P1-index | Tartalék ECU |
|---|---:|---:|
| water36.5 business0.4 | 57.12 | 258 133 |
| water40 business0 requested | 57.18 | 334 212 |
| communal5 parking8 water40 business0.3 | 57.49 | 260 577 |
| bureau wage650 trial | 57.82 | 216 729 |
| bureau wage800 | 58.24 | 160 029 |
| bureau800 water45 | 58.16 | 297 544 |
| bureau990 water50 accepted | 58.61 | 363 239 |
| parking10 communal actual lower bound | 58.72 | 352 904 |

| Súlyozott kategória | Előző terv | Mentett terv |
|---|---:|---:|
| Economy | 67.64 | 69.53 |
| Environment | 49.02 | 51.04 |
| Governance | 78.05 | 86.25 |
| Living conditions | 55.33 | 54.39 |
| Mobility | 54.5 | 54.66 |
| People | 30.43 | 30.45 |

## Pénzügyi ellenőrzés

Bevétel: 5 495 813 ECU; hitel/tartalék nélküli kiadás: 5 142 909 ECU. A különbség **352 904 ECU**. Az új döntések a bevételt 277 174 ECU-val, a kiadást 172 368 ECU-val növelték; a nettó javulás 104 806 ECU. Az előző és az új változatban a projektindítás és az eszközeladás változatlan.

A korábbi jelentések módszerével, kizárólag változatlan működési sorokat feltételezve: az egyszeri nyitópénz, osztalék, két fejlesztési támogatás és buszeladás nélkül a bevétel **5 075 751 ECU**; az egyszeri 388 000 ECU projektindítás/beruházás nélkül a kiadás **4 754 909 ECU**. Különbözetük **320 842 ECU** új projektek előtt (előző terv: 216 036 ECU). A korábbi feltételes 250 000 ECU/év projektkeret mellett ebből 70 842 ECU maradna, de ez nem igazolt P2-keret: a tényleges FACT, új lakosság, vállalkozások, támogatások és költségek alapján újra kell tervezni. Az eredeti natív projektmodell nem teljes adó–bér–díj szimulátor.

## Mentési igazolás

Mind a **10 fő fülön külön végső mentés** történt. A kurzusazonosságot minden ellenőrzött döntési panelnél és mentésnél vizsgáltam: Selejtező, I piac, P1/5. Újratöltés után mind az **55 döntési mező egyezett**, eltérés nincs. A pénzügy és az összesítő külön újratöltése megerősítette az 58,72-es indexet, a 352 904 ECU tartalékot és a négy projektindítást. Egy próba közti mentési visszajelzésre sikeres újrapróba történt; a végső tíz mentés mind igazolt.

A legfrissebb teljes mezőkészlet: review4/expected-inputs.json. További bizonyíték: review.json, persisted-inputs.json, checks.json, index-saved.png. A korábbi review/–review3/ és final fájlok történeti állapotokat őriznek.
