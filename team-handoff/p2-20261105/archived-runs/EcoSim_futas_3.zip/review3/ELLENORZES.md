> **Legfrissebb mentés:** 58,72 index; 352 904 ECU tartalék; 0 hitel. [Negyedik ellenőrzés](../review4/ELLENORZES.md). Az alábbi tartalom korábbi állapotot őriz.

# Harmadik utóellenőrzés – szélesebb P1-keresés

2026. november 3. · X-Challenge 2026 Selejtező · I piac · Jutalom a nap végén · P1/5.

**Mentett és újratöltve igazolt terv: 56,73 SmartCity index; 248 098 ECU tartalék; 0 hitel.** Az előző mentés 55,71 és 355 158 ECU volt: a javulás +1,02 pont, a tartalék 107 060 ECU-val kisebb. Ez P1-előnézet, nem lezárt eredmény és nem igazolt globális P5-optimum. A korábbi jelentések és final fájlok történeti állapotok; a végleges mezők jelenleg a review3/expected-inputs.json fájlban vannak.

## Keresés és döntési indok

15 teljes felületi változatot mértem, valamint a tényleges mezőkorlátokat is ellenőriztem. A vállalkozási adó csökkentése erősen javította az üzleti környezetet; a parkolási díj emelése a levegőminőséget és a közösségi közlekedést támogatta. Az alacsonyabb temetkezési, lakhatási és kommunális díj kisebb bevételvesztés mellett javított mutatókat. A felület a nullás temetkezési díjkérést 20-ra, a lakbérkérést 30-ra korlátozta: a végleges terv ezeket az elfogadott, pozitív díjakat tartalmazza. Az adókat nem tekintettem korábban feltételezett ±10/20%-os korlátúaknak; a jelenlegi elfogadott értékeket mértem.

A négy intézményi béremelés teljes visszaállítása 122 760 ECU-t takarított meg, de 0,38 pontot elvett az adott próbatervből. A városháza emelésének visszaadása önmagában 0,25 pontot hozott 33 642 ECU-ért, ezért a városházi 534-es bér megmaradt. Az egészségügyben 575-ös köztes értéket választottam; sport/kultúra és szociális ellátás esetén a P0 bérszint maradt. A képzési és fejlesztési összegek többségénél az emelési kérés visszakorlátozódott a már beállított értékre. Két szociális fejlesztési tételnél volt még engedett emelés: 45 500 és 58 500 ECU.

Az általános iskolákat változatlanul hagytam. A -1 óvoda és -1 bölcsőde próbája 0,05 ponttal kisebb indexet, de 34 321 ECU-val nagyobb tartalékot adott az adott kombinációban. A felszabaduló forrást hatékonyabb adó/díjintézkedésekre fordítottam. A kapacitás a céladatok szerint megfelelő: középiskola 99%, általános iskola 88%, óvoda 77%, bölcsőde 85%. A következő év tényleges korcsoportos igényét újra ellenőrizni kell.

A négy indított projekt változatlan: **12, 13, 27, 32**. A korábbi natív ötéves projektmodell összevetését nem írtam át és nem tekintettem teljes városi adó/bér/díjoptimalizálónak.

## A 14 új mezőváltozás az 55,71-es mentéshez képest

| Mező | Korábbi | Végleges |
|---|---:|---:|
| institutions.education.kindergarten.change | 0 | -1 |
| institutions.education.nursery.change | 0 | -1 |
| institutions.sport.wage | 510 | 425 |
| institutions.healthCare.wage | 660 | 575 |
| institutions.social.wage | 462 | 385 |
| institutions.homeRenovation.development | 42 000 | 45 500 |
| institutions.social.development | 54 000 | 58 500 |
| income.services.transportCost | 11 | 10.5 |
| income.services.burialCost | 29 | 20 |
| income.services.parkingManagementCost | 4.2 | 6 |
| income.services.communalCost | 7.7 | 7.3 |
| income.services.rentalCost | 40.5 | 30 |
| income.taxes.business | 1.6 | 0.8 |
| income.taxes.vehicle | 2.1 | 2.5 |

## Felületi összehasonlítások

Az alábbi címkék a nyers keresési napló változatnevei. A nullás díjpróba ténylegesen elfogadott értékei 20 és 30; a kért és elfogadott érték külön szerepel a checks.json naplóban.

| Változat | P1-index | Tartalék ECU |
|---|---:|---:|
| tax limit trial | 55.93 | 314 553 |
| business1.6 vehicle2.5 communal0.5 building0.1 | 55.73 | 346 785 |
| business1.3 isolated | 56.04 | 294 614 |
| fee bounds plus business1.3 | 56.17 | 250 358 |
| four institution wages P0 level | 55.79 | 373 118 |
| restore bureau wage only | 56.04 | 339 476 |
| bureau534 health575 sport425 social385 | 56.06 | 333 016 |
| business1.0 vehicle2.5 wage reallocation | 56.36 | 281 792 |
| targeted fees22 rent30 parking5.4 | 56.49 | 267 079 |
| kindergarten-1 nursery-1 isolated | 56.44 | 301 400 |
| funeral0 rental0 parking6 | 56.48 | 296 385 |
| business0.9 with fees and capacity | 56.6 | 276 203 |
| bureau environment extra | 56.6 | 276 203 |
| social development45500 58500 accepted limits | 56.62 | 268 279 |
| business0.8 plus social development | 56.73 | 248 098 |

## Pénzügyi ellenőrzés és gyakorlati korlát

Bevétel 5 218 639 ECU, hitel/tartalék nélküli kiadás 4 970 541 ECU, különbség 248 098 ECU. A kisebb tartalék és alacsonyabb adóbevétel a további projektkeretet szűkíti. A korábbi jelentésekhez hasonló, kizárólag változatlan működési sorokat feltételező érzékenységi számításban az egyszeri nyitópénz, osztalék, két fejlesztési támogatás és buszeladás nélkül a bevétel 4798577 ECU, az egyszeri 388 000 ECU projektindítás/beruházás nélkül a kiadás 4582541 ECU; különbözetük **216036 ECU**, új projektek előtt. Ez nem tényleges P2-keret. A feltételes 250 000 ECU/év későbbi projektkerethez önmagában nem elég a működési különbözet; a jelenlegi tartalék és a későbbi tényleges bevételek is szükségesek lehetnek. P2-ben a lezárt P1 FACT és az aktuális keretek alapján újratervezés kell.

## Mentés és kurzusazonosság

A végső újratöltés során az alkalmazás a lezárt Z piaci tesztkurzust mutatta. További módosítás előtt visszaválasztottam a Courses oldalon a Selejtező kurzust. Az I piaci P1 összesítőben a **56,73-as terv megmaradt**. Ezután az összes mezőt és a pénzügyet újratöltve ellenőriztem. **Mind az 55 döntési mező pontosan egyezett; mind a 10 fő fülön külön sikeres végső mentés történt.** Az összesítő külön újratöltése igazolta az indexet és a négy projektindítást. A tesztkurzus eredménynézetében nem végeztem döntési módosítást.

Bizonyítékok: review.json, checks.json, expected-inputs.json, persisted-inputs.json, index-saved.png; a kurzusváltást külön state-change.txt dokumentálja. A nyers fájlok kizárólag helyben vannak.
