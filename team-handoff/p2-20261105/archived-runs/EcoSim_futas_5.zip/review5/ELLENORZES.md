# Ötödik ellenőrzés

X-Challenge 2026 Selejtező, I piac, P1/5, 2026. november 3.

Az EcoSim a mentési visszajelzést követően 58,87-es SmartCity tervindexet, 309 280 ECU tartalékot és 0 ECU hitelfelvételt mutatott. Az előző, újratöltéssel ellenőrzött 58,72-es tervhez képest ez 0,15 pont javulás, 43 624 ECU-val kisebb tartalék mellett. A kijelzett bevétel 5 475 892 ECU, a hitel és tartalék nélküli kiadás 5 166 611 ECU volt. A két kijelzett összeg különbsége kerekítés miatt 1 ECU-val tér el a kijelzett tartaléktól.

Az összefoglaló és a mezőlista a beszélgetésben rögzített felületi mérésekből készült. Az automatikus jóváhagyási ellenőrzés használati limit miatt elutasította a záró újratöltést. Ezért az összes fül végső mentése és az 55 mező visszaellenőrzése elmaradt. Az expected-inputs.json a megfigyelt döntésekből rekonstruált mezőlista.

| Mért változat | P1-index | Tartalék (ECU) |
|---|---:|---:|
| Kiinduló, előzőleg ellenőrzött terv | 58,72 | 352 904 |
| Buszvezetői és közlekedési irodai képzés 50 | 58,75 | 343 700 |
| Közlekedési kommunikáció 50 000 | 58,75 | 343 700 |
| Kommunikáció vissza 33 600, szolgáltatói bér 395 | 58,74 | 387 458 |
| Szociális bér 462, egészségügyi bér 580 | 58,75 | 363 851 |
| Parkolási díj próbája, elfogadott érték 10 | 58,75 | 363 851 |
| Kommunális adó 0,4%, építményadó 0,1% | 58,81 | 343 609 |
| Óvodai és bölcsődei kapacitás visszaállítása | 58,87 | 309 280 |

| Mező | Előző érték | Utolsó mért érték |
|---|---:|---:|
| Buszvezetői képzés | 39 | 50 |
| Közlekedési irodai képzés | 32 | 50 |
| Szolgáltatói bér | 415 | 395 |
| Szociális bér | 385 | 462 |
| Egészségügyi bér | 575 | 580 |
| Kommunális adó | 0,9% | 0,4% |
| Építményadó | 0,4% | 0,1% |
| Óvodák számának változása | −1 | 0 |
| Bölcsődék számának változása | −1 | 0 |
