> **Legfrissebb mentés:** 58,72 index; 352 904 ECU tartalék; 0 hitel. [Negyedik ellenőrzés](../review4/ELLENORZES.md). Az alábbi tartalom korábbi állapotot őriz.

> **Legfrissebb mentés:** 56,73 index; 248 098 ECU tartalék; 0 hitel. [Harmadik utóellenőrzés](../review3/ELLENORZES.md). Az alábbi tartalom korábbi állapotot dokumentál.

# Második utóellenőrzés – végleges P1-terv

2026. november 3., Selejtező, I piac, Jutalom a nap végén, P1/5.

A mentett terv **55,71 SmartCity indexet**, **355 158 ECU tartalékot**, **0 hitelt** mutat. A korábbi 55,56 / 403 928 ECU állapothoz képest ez **+0,15 pont**, 48 770 ECU-val kisebb tartalékkal. A mutató továbbra is P1-terv, nem lezárt eredmény.

| Új módosítás | Korábbi | Végleges |
|---|---:|---:|
| Buszvezetők felvétele | +35 | +50 |
| Dízelbusz-karbantartás | 175 000 | 192 500 |
| Elektromos busz-karbantartás | 15 000 | 18 000 |
| Kommunális szolgáltatási díj/fő | 8,5 | 7,7 |

A projektcsomag változatlan: 12, 13, 27, 32. A korábbi review/ mappa a köztes 55,56-os állapotot őrzi; az eredeti final fájlok az 55,49-es változatot. **Az aktuális döntések itt a review2/expected-inputs.json állományban találhatók.**

## Kontrollált felületi próbák

| Próba, egymásra épülő változatok | P1-index | Tartalék ECU |
|---|---:|---:|
| Kiinduló mentés | 55,56 | 403 928 |
| Kommunális díj 9,4 és víz/fűtés 36,5 | 55,43 | 519 441 |
| Kommunális díj 7,7, víz/fűtés vissza 33,2 | 55,63 | 381 926 |
| Kommunális díj 7,7 és víz/fűtés 29,9 | 55,69 | 291 166 |
| Víz/fűtés vissza 33,2, szerelői bér 576 | 55,63 | 378 662 |
| További vezetői bér 506 | 55,63 | 365 322 |
| Bérek vissza 480/460, vezetői felvétel +50 | 55,68 | 375 254 |
| További dízelkarbantartás 192 500 | 55,70 | 358 098 |
| További elektromos karbantartás 18 000 | **55,71** | **355 158** |

A drágább vízdíj-csökkentést és a bérpróbákat visszaállítottam. A szerelők +14 fős próbakérését a felület +10-re korlátozta; így maradt 34 szerelő. Nem kerültem meg a korlátozást. A friss repó R234/R235 dokumentációja is jelzi, hogy a korlátok periódusfüggők; a döntést a ténylegesen elfogadott értékekre és aktuális felületi mérésekre alapoztam. Új teljes városi vagy ötéves optimalizálót nem állítottam elő; globális optimumot ezek a próbák nem igazolnak.

## Kapacitás és pénzügy

- 62 dízel és 5 elektromos busz: 93,69% kihasználtság.
- Közlekedési minőség: 72,16%; infrastruktúra minősége: 60,00%.
- 305 vezető: 87,87% terhelés; 34 szerelő: 93,07%; 341 irodai dolgozó: 82,07%.
- Bevétel: 5 434 718 ECU; hitel/tartalék nélküli kiadás: 5 079 560 ECU; különbség: 355 158 ECU.
- A többletráfordítás és a csökkentett díj a későbbi évek pénzügyi mozgásterét is érinti. A folytatásnál a lezárt P1 FACT és az új keretek alapján újra kell tervezni.

## Mentési ellenőrzés

Mind a **10 fő fülön külön végső mentés** történt. Újratöltés után mind az **55 döntési mező pontosan egyezett**, eltérés nincs. Az összesítő és pénzügy külön újratöltése megerősítette az 55,71-es indexet, a 355 158 ECU tartalékot és a négy projektindítást. A próbák közti átmeneti mentési hibát sikeres újrapróba követte; a végső 10 mentés mind igazolt.

Bizonyítékok: review.json, checks.json, persisted-inputs.json, expected-inputs.json, index-saved.png.
