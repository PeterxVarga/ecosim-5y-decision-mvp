# EcoSim R197 – közös állapotú városi döntési dosszié

Csak olvasó, meglévő R195 és R149–R159 kimenetekhez illesztett ellenőrző réteg. **Nem új optimalizáló; nem teljes városgazdálkodási E2E.**

A meglévő R149 `decision_desk_r149.py` az R153 adóérzékenységi, R154 adóbevételi, R155 díj-/intézményi, R158–R159 pénzáram-időzítési részmodelleket elő tudja állítani. Az R197 csak azok és az R195 azonos állapothashét köti össze; a két eltérő jelölthalmaz és policy-pálya nem közvetlenül rangsorolható.

## Futtatás

```bash
python3 bridge_r197.py \
  --tradeoff /tmp/ecosim-r195-tradeoff-2qiKmOEe/TRADEOFF.json \
  --decision-desk /path/to/DECISION_DESK.json \
  --out-json /tmp/ecosim-r197-city.json \
  --out-md /tmp/ecosim-r197-city.md
```

Opcionálisan `--city-review /path/to/R196.json`. A R149 döntési dosszié forrásának **pontosan ugyanabból a state JSON-ból kell származnia**, mint az R195 futása; a fájlhossztól és sorrendtől is függő SHA-256 azonosság megkövetelt. A kimeneti útvonalak nem írhatnak felül meglévő fájlokat.

## Kvalifikáció

- 7/7 célzott helyi teszt PASS (státusz- és identitáshibákat is tartalmaz).
- A felhasználó Fedora gépén az eredeti R149–R159 történeti döntési motor **PASS** (15 projektjelölt), az R195-ben már használt történeti inputállapotra átállítva.
- A R197 teljes natív futása e két valódi kimeneten **még nincs kvalifikálva**; ne merge-eld mainre ilyen bizonyíték nélkül.
- `GAME_ACTION_GATE=STOP`; sem hálózati EcoSim művelet, sem szerveroldali pontossági állítás.

## Nyitott akadályok

Azonos projektjelölteken és policy-pályákon kell az összes hatást újraértékelni, figyelembe véve a cash-flow és finanszírozás korlátait. A 10 fül adatgyűjtését az R196 ellenőrzi. A R197 jelenleg bizonyítottan csak a kiinduló állapotazonosságot képes ellenőrizni; az adó-/működési pályák hatását **nem adja hozzá** az R195 pontszámához, és egyetlen ellenőrzött aktuális javaslatot sem generál.
