# EcoSim – R206 történeti forrásazonos keresési próba (2026. november 2.)

**Történeti, teljesen offline modellfuttatás; nem éles ajánlás. GAME_ACTION_GATE=STOP.**

Az eredeti R162 projektkereső, költségnaptár és 35 kártyás katalógus aktuális GitHub-forrásazonosságát egyeztettük. Az R94 történeti p1 PLAN-t használtuk, nem valós éles állapotot.

| Hipotetikus szcenárió | Éves projektdíj-plafon | Alap indítási darabszám | R162 jelöltek | R160 feltételmentes / feltételes |
|---|---:|---:|---:|---|
| LOW | 50,000 ECU | 3 | 3 | 3 / 0 |
| MID | 90,000 ECU | 4 | 3 | 3 / 0 |
| HIGH | 150,000 ECU | 4 | 3 | 1 / 2 |

## Szcenáriónkénti legjobb *részmodell* jelölt

| Szcenárió | 1. évben induló projektazonosítók | Ötéves kártyaköltség | Közvetlen 5. évi proxy Δ | Nem leképezett hatások | R160 státusz |
|---|---|---:|---:|---:|---|
| LOW | 26, 27, 28 | 237,500 ECU | +0.812014 | 12 | PASS_DISPLAY_RULES_ONLY_NOT_SERVER_APPROVAL |
| MID | 13, 17, 27, 28 | 436,300 ECU | +1.248362 | 17 | PASS_DISPLAY_RULES_ONLY_NOT_SERVER_APPROVAL |
| HIGH | 4, 8, 13, 27 | 711,600 ECU | +1.613609 | 22 | CONDITIONAL_NOT_SERVER_VERIFIED |

## Bizonyítási határ

A három keret (50k/90k/150k) és a projektlimit (3/4/4) **hipotetikus**, nem áll rendelkezésre hozzájuk éles, igazolt finanszírozás.
A HIGH szcenárióban később 5 projekt is előfordulhat, mert az eredeti kód feltételezett előző évi project1 bónuszt alkalmaz; ezt a szerver még nem igazolta.
Az R160 megállapításai kizárólag a képernyőn látható feltételek és a kártyaköltség független visszajátszására vonatkoznak.
A teljes R206 kapu (privát R200/R204/R205 forrásazonosító csomagok és az R204 17 tervével való egyedi összevetés) **nem futott le**: a Fedora offline.
A tényleges éles finanszírozás, intézmények, lakossági reakciók, hitelek, szerveres pontozás és a többi város adatai nincsenek modellezve.

GAME_ACTION_GATE=STOP; game_writes=0.
