# EcoSim R209 – ötéves projekt- és pénzügyi részmodellek közös futása

**TÖRTÉNETI P1 TERV + SZINTETIKUS GAZDASÁGPOLITIKÁK. NEM ÉLES PÉNZÜGYI ELŐREJELZÉS. GAME_ACTION_GATE=STOP.**

Az eredeti R162 projektkeresőt és R153 adóhatás-, R154 négyadó-bevétel-, R155 díj/intézményi működés- és R159 időzítési modellt közvetlenül újrahasználtam.

12 ötéves terv × 3 hipotetikus adó/működési pálya = **36 pontos projekt–politika kombináció**. Mind a 36 eset projektazonosítói és kártyaköltségei egyeztek az eredeti tervvel; a negatív drift-tesztek blokkoltak.

## Három mintaterv (R162 scenario_min cél szerint)

| Szintetikus éves kártyaplafon | 1. évi projektek | 5 év projektráfordítás | 5 év részleges pénzügyi nettó a három szintetikus pályán (min…max) |
|---:|---|---:|---:|
| 75,000 ECU | 13, 27 | 358,700 ECU | -1,397,735 … 633,299 ECU |
| 120,000 ECU | 4, 13, 27, 28 | 590,700 ECU | -1,629,735 … 401,299 ECU |
| 150,000 ECU | 4, 13, 26, 27 | 706,100 ECU | -1,745,135 … 285,899 ECU |

**Ezek a nettók kizárólag részleges, mesterséges bevételi és intézményi forgatókönyvek.** Nem azonosak az induló pénzállománnyal, a szerver tényleges cash flow-jával vagy a szabad projekttőkével. A modell nem tartalmazza az összes bevételt, kiadást, támogatást, hitelt, valódi gazdasági visszacsatolást vagy a szerveres pontozást.

A három pontozási modell közvetlen projektproxy, az R153-változás csak ismert faktorformula. R208-ban a magas keretű jelölt nominal keresési célú volt; itt minden terv scenario_min célú, ezért az elsőéves projektazonosítók eltérhetnek.

**Státusz:** forrásazonosított szintetikus modell-integráció PASS, élő használhatóság HOLD, játékbeli művelet 0.
