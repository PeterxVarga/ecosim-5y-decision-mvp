# EcoSim R208 — történeti forráskódos döntési próba

**OFFLINE PASS, DE NEM ÉLES ADAT, NEM JÁTÉKBELI JAVASLAT. GAME_ACTION_GATE=STOP.**

Az R156 valódi beolvasó és az R162/R157/R160 eredeti motor futott történeti p1 PLAN értékekkel.
A CURRENT_READONLY bizonyíték és az R191/R192 kapunyugták SZINTETIKUS TESZTSEGÉDLETEK, nem valódi élő adatok.

3 keresés, 12 teljes R160-auditált ötéves terv, 4 különböző elsőéves választás, 3 megjelenített alternatíva.

| Mintaéves korlát | Elsőéves projektek | Kártyaköltség (ECU) | Mintában legrosszabb R157 közvetlen hatás Δ | Folytatások |
|---:|---|---:|---:|---:|
| 75,000 | 13, 27 | 70,000 | +0.372976 | 4 |
| 120,000 | 4, 13, 27, 28 | 118,000 | +0.470440 | 2 |
| 150,000 | 4, 8, 13, 27 | 142,000 | +0.515249 | 4 |

A három mintaplafon nem tényleges költségvetés; a hatások közvetlen projektproxyk, nem SmartCity-előrejelzések.
A valódi éles R156→R191→R192→R207 adatút és a privát R206 forrásazonosítás továbbra is HOLD.
